<template>
	<view>
		<view>
		  <ul class="nav nav-tabs nav-justified disFl">
		  <li role="presentation" class="active"><a href="#">三日充值明细</a></li>
		  <li role="presentation"><a href="#">三日接单明细</a></li>
		  <li role="presentation"><a href="#">三日账户变动明细</a></li>
		  </ul>
		</view>
		<view>
			
		</view>
	</view>
</template>

<script>
	import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
</script>

<style>
	.disFl {
		display: flex;
	}
</style>